from django.db import models
from users.models import Doctor, Patient
from cryptography.fernet import Fernet
from django.conf import settings

class DoctorNote(models.Model):
    doctor = models.ForeignKey(Doctor, on_delete=models.CASCADE)
    patient = models.ForeignKey(Patient, on_delete=models.CASCADE)
    encrypted_content = models.BinaryField()

    def encrypt_content(self, content):
        cipher = Fernet(settings.ENCRYPTION_KEY)
        self.encrypted_content = cipher.encrypt(content.encode())

    def decrypt_content(self):
        cipher = Fernet(settings.ENCRYPTION_KEY)
        return cipher.decrypt(self.encrypted_content).decode()
