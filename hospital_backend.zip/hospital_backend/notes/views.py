from rest_framework import generics
from .models import DoctorNote
from .serializers import DoctorNoteSerializer

class DoctorNoteCreateView(generics.CreateAPIView):
    queryset = DoctorNote.objects.all()
    serializer_class = DoctorNoteSerializer
